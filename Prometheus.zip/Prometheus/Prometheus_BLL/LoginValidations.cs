﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prometheus_Entity;
using Prometheus_Exeception;
using Prometheus_DAL;
using System.Data;
using System.Data.SqlClient;

namespace Prometheus_BLL
{
    public class LoginValidations
    {
        public bool IsLogin_BLL(int ID,string password,int selection)
        {
            bool isValid = false;
            try
            {
                LoginOperations obj = new LoginOperations();
                isValid = obj.IsLogin_DAL(ID,password, selection);
            }
            catch(PExeception ex) { throw ex; }
            catch(SqlException ex) { throw ex; }
            catch(Exception ex) { throw ex; }
            return isValid;
        }
    }
}
