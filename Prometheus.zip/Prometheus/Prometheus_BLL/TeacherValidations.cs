﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prometheus_Entity;
using Prometheus_Exeception;
using Prometheus_DAL;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace Prometheus_BLL
{
    public class TeacherValidations
    {
        TeacherOperations obj = new TeacherOperations();
        public DataTable searchTeacher_BLL(int teacherID)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = obj.searchTeacher_DAL(teacherID);
            }
            catch (PExeception ex) { throw ex; }
            catch (SqlException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            return dt;
        }
        public int updateTeacher_BLL(Teacher teacher)
        {
            int rowsaffected = 0;
            bool isValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
               
                if (teacher.FName == string.Empty)
                {
                    message.Append("Teacher First Name should be provided\n");
                    isValidated = false;
                }
                //To validate Last name
                if (teacher.LName == string.Empty)
                {
                    message.Append("Teacher Last Name should be provided\n");
                    isValidated = false;
                }

                //To validate address
                if (teacher.Address == string.Empty)
                {
                    message.Append("Teacher Address should be provided\n");
                    isValidated = false;
                }
                //To  validate date of birth
                int age = DateTime.Now.Year - teacher.DOB.Year;
                if (age < 18 || age > 60)
                {
                    message.Append("Teacher age should be in range 18 to 60\n");
                    isValidated = false;
                }
                //To validate city
                if (teacher.City == string.Empty)
                {
                    message.Append("Teacher City should be provided\n");
                    isValidated = false;
                }
                //Password Validation
                if (teacher.Password == string.Empty)
                {
                    message.Append("Password should not be empty\n");
                    isValidated = false;
                }

                //Mobile No validation
                if (!Regex.IsMatch(Convert.ToString(teacher.MobileNo), "[0-9]{10}"))
                {
                    message.Append("Phone number should have exactly 10 digits\n");
                    isValidated = false;
                }


                if (isValidated == false)
                    throw new Exception(message.ToString());

                rowsaffected = obj.updateTeacher_DAL(teacher);
            }
            catch (PExeception ex) { throw ex; }
            catch (SqlException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            return rowsaffected;
        }
    }
}
