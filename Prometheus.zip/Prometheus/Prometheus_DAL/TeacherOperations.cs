﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prometheus_Entity;
using Prometheus_Exeception;

namespace Prometheus_DAL
{
    class TeacherOperations
    {

    }
}
