﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prometheus_Entity;
using Prometheus_Exeception;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Prometheus_DAL
{
    public class TeacherOperations
    {
        SqlConnection empConnObj = null;
        SqlCommand empCommand = null;
        SqlDataReader empReader = null;
        DataTable dt = new DataTable();
        string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        
        public DataTable searchTeacher_DAL(int teacherID)
        {
            try
            {
                empConnObj = new SqlConnection();
                empConnObj.ConnectionString = empConnStr;
                empCommand = new SqlCommand("Group1.usp_SearchTeacher", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empCommand.Parameters.AddWithValue("@Tid", teacherID);
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dt.Load(empReader);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open)
                    empConnObj.Close();
            }
            return dt;
        }
        public int updateTeacher_DAL(Teacher teacher)
        {
            int rowAffected = 0;
            try
            {
                empConnObj = new SqlConnection();
                empConnObj.ConnectionString = empConnStr;
                empCommand = new SqlCommand("Group1.usp_UpdateTeacher", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empCommand.Parameters.AddWithValue("@Tid", teacher.TeacherID);
                empCommand.Parameters.AddWithValue("@Fname", teacher.FName);
                empCommand.Parameters.AddWithValue("@Lname", teacher.LName);
                empCommand.Parameters.AddWithValue("@address", teacher.Address);
                empCommand.Parameters.AddWithValue("@dob", teacher.DOB);
                empCommand.Parameters.AddWithValue("@city", teacher.City);
                empCommand.Parameters.AddWithValue("@password",teacher.Password);
                empCommand.Parameters.AddWithValue("@mobileNo", teacher.MobileNo);
                empCommand.Parameters.AddWithValue("@isAdmin", teacher.IsAdmin);
                empConnObj.Open();
                rowAffected = empCommand.ExecuteNonQuery();

            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (empConnObj.State == ConnectionState.Open) empConnObj.Close();
            }
            return rowAffected;
        }
    }
}
