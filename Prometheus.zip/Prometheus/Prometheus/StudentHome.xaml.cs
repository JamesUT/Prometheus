﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Prometheus_Entity;
using Prometheus_BLL;
using Prometheus_Exeception;

namespace Prometheus
{
    /// <summary>
    /// Interaction logic for StudentHome.xaml
    /// </summary>
    public partial class StudentHome : Window
    {
        SqlConnection connObj = null;
        SqlDataReader reader = null;
        SqlCommand cmd = null;
        string connStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        DataTable dt = null;
        int studID = 0;

        public StudentHome(string studentID)
        {
            InitializeComponent();
            studID = Convert.ToInt32(studentID);
            connObj = new SqlConnection();
            connObj.ConnectionString = connStr;
            cmd = new SqlCommand("Select Enrollment.CourseID from Group1.Enrollment where IsEnrollment = @IsEnrollment AND StudentID = @StudentID", connObj);
            connObj.Open();
            cmd.Parameters.AddWithValue("@IsEnrollment", false);
            cmd.Parameters.AddWithValue("@StudentID", Convert.ToInt32(studentID));
            dt = new DataTable();
            reader = cmd.ExecuteReader();
            if(reader.HasRows)
            {
                dt.Load(reader);
            }
            foreach (DataRow row in dt.Rows)
            {
                cb_enrollment.Items.Add(row["CourseID"]);
            }
            cb_enrollment.SelectedIndex = 0;
        }

        private void btn_enrollment_Click(object sender, RoutedEventArgs e)
        {
            connObj = new SqlConnection();
            connObj.ConnectionString = connStr;
            int rowAffected = 0;
            cmd = new SqlCommand("Update Group1.Enrollment set IsEnrollment='true' where StudentID = @StudentID", connObj);
            connObj.Open();
            cmd.Parameters.AddWithValue("@StudentID", Convert.ToInt32(studID));
            dt = new DataTable();
            rowAffected = cmd.ExecuteNonQuery();

            if(rowAffected > 0)
            {
                MessageBox.Show("Course Enrolled!");
                StudentHome obj = new StudentHome(Convert.ToString(studID));
                obj.Show();
                this.Close();
            }
        }

        private void btn_updateinformation_Click(object sender, RoutedEventArgs e)
        {
            StudentUpdateInformation studUpdate = new StudentUpdateInformation(studID);
            studUpdate.Show();
        }

        private void btn_signOut_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
