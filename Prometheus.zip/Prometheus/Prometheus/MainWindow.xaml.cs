﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Prometheus_Entity;
using Prometheus_BLL;
using Prometheus_Exeception;

namespace Prometheus
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_login_Click(object sender, RoutedEventArgs e)
        {
            LoginValidations loginValid;
            bool isValid;

            if (rb_admin.IsChecked == true)
            {
                loginValid = new LoginValidations();
                isValid = loginValid.IsLogin_BLL(Convert.ToInt32(txt_userID.Text), pb_password.Password.ToString(), 1);
                if (isValid == true)
                {
                    TeacherHome teacherObj = new TeacherHome();
                    teacherObj.Show();
                }
                else
                {
                    MessageBox.Show("Please provide correct 'UserID' and 'Password'.");
                }
            }
            else if (rb_teacher.IsChecked == true)
            {
                loginValid = new LoginValidations();
                isValid = loginValid.IsLogin_BLL(Convert.ToInt32(txt_userID.Text),pb_password.Password.ToString(),2);
                if(isValid == true)
                {
                    TeacherHome teacherObj = new TeacherHome();
                    teacherObj.Show();
                }
                else
                {
                    MessageBox.Show("Please provide correct 'UserID' and 'Password'.");
                }
            }
            else if (rb_student.IsChecked == true)
            {
                MessageBox.Show("Not Implemented!!");
            }
            else
            {
                MessageBox.Show("Please Check one of the login option!");
            }
        }
    }
}
