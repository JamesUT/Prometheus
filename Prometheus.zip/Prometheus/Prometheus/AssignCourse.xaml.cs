﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Prometheus
{
    /// <summary>
    /// Interaction logic for AssignCourse.xaml
    /// </summary>
    public partial class AssignCourse : Window
    {
        Hashtable htcourse = new Hashtable();
        Hashtable htstudent = new Hashtable();
        public AssignCourse(string teacherID)
        {
            InitializeComponent();
            SqlConnection empConnObj = null;
            SqlConnection ConnObj = null;
            SqlDataReader empReader = null;
            SqlDataReader cmdReader = null;
            DataTable dt = new DataTable();
            DataTable dt2 = new DataTable();
            string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
            try
            {
                empConnObj = new SqlConnection();
                empConnObj.ConnectionString = empConnStr;
                SqlCommand empCommand = new SqlCommand("SELECT Course.CourseID , Course.CourseName FROM  Group1.Teaches INNER JOIN Group1.Course ON Teaches.CourseID = Course.CourseID AND Teaches.TeacherID = @TeacherID", empConnObj);
                empCommand.Parameters.AddWithValue("@TeacherID", Convert.ToInt32(teacherID));
                empConnObj.Open();
                
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dt.Load(empReader);
                }
                foreach (DataRow row in dt.Rows)
                {
                    comboBox.Items.Add(row["CourseName"]);
                    htcourse.Add(row["CourseName"].ToString(),row["CourseID"].ToString());
                }
                comboBox.SelectedIndex = 0;
                ConnObj = new SqlConnection();
                ConnObj.ConnectionString = empConnStr;
                SqlCommand cmd = new SqlCommand("SELECT Distinct * from Group1.Student", ConnObj);
                ConnObj.Open();

                cmdReader = cmd.ExecuteReader();
                if(cmdReader.HasRows)
                {
                    dt2.Load(cmdReader);
                }
                foreach (DataRow row2 in dt2.Rows)
                {
                    listBox.Items.Add(row2["FName"] + " " + row2["LName"]);
                    htstudent.Add((row2["FName"] + " " + row2["LName"]).ToString(), row2["StudentID"].ToString());
                    //MessageBox.Show(row2["FName"] + " " + row2["LName"] + "  " + row2["StudentID"].ToString());
                }
                listBox.SelectAll();
                

            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open)
                    empConnObj.Close();
            }
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            List<string> list = new List<string>();
            foreach (string item in listBox.SelectedItems)
            {
                
                list.Add(item);
                
                listBox_Copy.Items.Add(item);
            }
            foreach (string item in list)
            {
                listBox.Items.Remove(item);
            }
        }


        private void btn_remove_Click_1(object sender, RoutedEventArgs e)
        {
            List<string> list = new List<string>();
            foreach (string item in listBox_Copy.SelectedItems)
            {

                list.Add(item);

                listBox.Items.Add(item);
            }
            foreach (string item in list)
            {
                listBox_Copy.Items.Remove(item);
            }
        }

        private void btn_assignCourse_Click_1(object sender, RoutedEventArgs e)
        {
            SqlConnection ConnObj = null;
            int rowaffected = 0;
            string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
            try
            {
                ConnObj = new SqlConnection();
                ConnObj.ConnectionString = empConnStr;

                int courseID = Convert.ToInt32(htcourse[comboBox.SelectedItem.ToString()]);

                foreach (string item in listBox_Copy.Items)
                {
                    SqlCommand cmd = new SqlCommand("Insert Into [Group1].[Enrollment] values (@CourseID,@StudentID,@IsEnrollment,@CourseName)", ConnObj);
                    int studentID = Convert.ToInt32(htstudent[item]);
                    cmd.Parameters.AddWithValue("@CourseID", courseID);
                    cmd.Parameters.AddWithValue("@StudentID", studentID);
                    cmd.Parameters.AddWithValue("@IsEnrollment", false);
                    cmd.Parameters.AddWithValue("@CourseName", comboBox.SelectedItem.ToString());
                    //MessageBox.Show(studentID + "  " + courseID);
                    ConnObj.Open();
                    rowaffected = cmd.ExecuteNonQuery();
                    ConnObj.Close();
                }
                if (rowaffected > 0)
                {
                    MessageBox.Show("Courses Assigned!");
                }
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (ConnObj.State == ConnectionState.Open)
                    ConnObj.Close();
            }
        }
    }
}