﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Prometheus_Entity;
using Prometheus_Exeception;


namespace Prometheus
{
    /// <summary>
    /// Interaction logic for TeacherSearch.xaml
    /// </summary>
    public partial class TeacherSearch : Window
    {
        public TeacherSearch(string teacherID,bool isAdmin)
        {
            InitializeComponent();
            //MessageBox.Show("Teacher ID :" + teacherID);
            lbl_teacherID.Content = teacherID;
            if(isAdmin == true)
            {
                btn_Teacher.Visibility = Visibility.Visible;
            }
            else
            {
                btn_Teacher.Visibility = Visibility.Hidden;
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection empConnObj = null;
            SqlCommand empCommand = null;
            SqlDataReader empReader = null;
            DataTable dt = new DataTable();
            string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
            try
            {
                empConnObj = new SqlConnection();
                empConnObj.ConnectionString = empConnStr;
                empCommand = new SqlCommand("[Group1].[usp_TeacherCourses]", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empCommand.Parameters.AddWithValue("@TeacherID", Convert.ToInt32(lbl_teacherID.Content.ToString()));
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dt.Load(empReader);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open)
                    empConnObj.Close();
            }
            dg_Display.ItemsSource = dt.DefaultView;
        }

        private void btn_Students_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection empConnObj = null;
            SqlCommand empCommand = null;
            SqlDataReader empReader = null;
            DataTable dt = new DataTable();
            string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
            try
            {
                empConnObj = new SqlConnection();
                empConnObj.ConnectionString = empConnStr;
                empCommand = new SqlCommand("Group1.usp_DisplayStudent", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dt.Load(empReader);
                }
                //dg_Display.ItemsSource = dt.DefaultView;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open)
                    empConnObj.Close();
            }
            dg_Display.ItemsSource = dt.DefaultView;
        }


        private void btn_Homework_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection empConnObj = null;
            SqlCommand empCommand = null;
            SqlDataReader empReader = null;
            DataTable dt = new DataTable();
            string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
            try
            {
                empConnObj = new SqlConnection();
                empConnObj.ConnectionString = empConnStr;
                empCommand = new SqlCommand("Group1.usp_DisplayHomework", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;

                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dt.Load(empReader);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open)
                    empConnObj.Close();
            }
            dg_Display.ItemsSource = dt.DefaultView;
        }

        private void btn_Teacher_Click(object sender, RoutedEventArgs e)
        {
            SqlConnection empConnObj = null;
            SqlCommand empCommand = null;
            SqlDataReader empReader = null;
            DataTable dt = new DataTable();
            string empConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
            try
            {
                empConnObj = new SqlConnection();
                empConnObj.ConnectionString = empConnStr;
                empCommand = new SqlCommand("[Group1].[usp_DisplayTeacher]", empConnObj);
                empCommand.CommandType = CommandType.StoredProcedure;
                empConnObj.Open();
                empReader = empCommand.ExecuteReader();
                if (empReader.HasRows)
                {
                    dt.Load(empReader);
                }
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                empReader.Close();
                if (empConnObj.State == ConnectionState.Open)
                    empConnObj.Close();
            }
            dg_Display.ItemsSource = dt.DefaultView;

        }
    }
}