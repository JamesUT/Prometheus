﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Prometheus_Entity;
using Prometheus_BLL;
using Prometheus_Exeception;

namespace Prometheus
{
    /// <summary>
    /// Interaction logic for AdminPortal.xaml
    /// </summary>
    public partial class AdminPortal : Window
    {
        SqlConnection connObj = null;
        SqlDataReader reader = null;
        SqlCommand cmd = null;
        string connStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();

        public AdminPortal()
        {
            InitializeComponent();
            cb_option.Items.Add("Teacher");
            cb_option.Items.Add("Student");
            cb_option.Items.Add("Course");
            cb_option.SelectedIndex = 0;
        }

        private void cb_option_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if(cb_option.SelectedItem.ToString() == "Teacher")
            {
                grid_teacherAndStudent.Visibility = Visibility.Visible;
                grid_course.Visibility = Visibility.Hidden;
            }
            else if (cb_option.SelectedItem.ToString() == "Student")
            {
                grid_teacherAndStudent.Visibility = Visibility.Visible;
                grid_course.Visibility = Visibility.Hidden;
            }
            else if (cb_option.SelectedItem.ToString() == "Course")
            {
                grid_teacherAndStudent.Visibility = Visibility.Hidden;
                grid_course.Visibility = Visibility.Visible;
            }
            else
            {
                MessageBox.Show("Wrong Selection of 'Option' Combo Box.");
            }

        }

        private void btn_update_Click(object sender, RoutedEventArgs e)
        {
            int rowAffected = 0;
            if (cb_option.SelectedItem.ToString() == "Teacher")
            {
                
                connObj = new SqlConnection();
                connObj.ConnectionString = connStr;
                cmd = new SqlCommand("Group1.usp_AddTeacher", connObj);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Fname", txt_FName.Text);
                cmd.Parameters.AddWithValue("@Lname", txt_LName.Text);
                cmd.Parameters.AddWithValue("@address", txt_address.Text);
                cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(dp_DOB.Text));
                cmd.Parameters.AddWithValue("@city", txt_city.Text);
                cmd.Parameters.AddWithValue("@password", "ABCD");
                cmd.Parameters.AddWithValue("@mobileNo", Convert.ToInt64(txt_mNo.Text));
                cmd.Parameters.AddWithValue("@isAdmin", false);
                connObj.Open();

                rowAffected = cmd.ExecuteNonQuery();
                if (rowAffected > 0)
                {
                    MessageBox.Show("Teacher Added!");
                }
            }
            else if (cb_option.SelectedItem.ToString() == "Student")
            {
                grid_teacherAndStudent.Visibility = Visibility.Visible;
                grid_course.Visibility = Visibility.Hidden;
                connObj = new SqlConnection();
                connObj.ConnectionString = connStr;
                cmd = new SqlCommand("Group1.usp_AddStudent", connObj);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Fname", txt_FName.Text);
                cmd.Parameters.AddWithValue("@Lname", txt_LName.Text);
                cmd.Parameters.AddWithValue("@address", txt_address.Text);
                cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(dp_DOB.Text));
                cmd.Parameters.AddWithValue("@city", txt_city.Text);
                cmd.Parameters.AddWithValue("@password", "ABCD");
                cmd.Parameters.AddWithValue("@mobileNo", Convert.ToInt64(txt_mNo.Text));
                connObj.Open();

                rowAffected = cmd.ExecuteNonQuery();
                if (rowAffected > 0)
                {
                    MessageBox.Show("Teacher Added!");
                }
            }
            else if (cb_option.SelectedItem.ToString() == "Course")
            {
                grid_teacherAndStudent.Visibility = Visibility.Hidden;
                grid_course.Visibility = Visibility.Visible;
                connObj = new SqlConnection();
                connObj.ConnectionString = connStr;
                cmd = new SqlCommand("Group1.usp_AddCourse", connObj);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@coursename", txt_CName.Text);
                cmd.Parameters.AddWithValue("@startdate", Convert.ToDateTime(dp_CStartDate.Text));
                cmd.Parameters.AddWithValue("@startdate", Convert.ToDateTime(dp_CEndDate.Text));
                connObj.Open();

                rowAffected = cmd.ExecuteNonQuery();
                if (rowAffected > 0)
                {
                    MessageBox.Show("Teacher Added!");
                }
            }
            else
            {
                MessageBox.Show("Wrong Selection of 'Option' Combo Box.");
            }
        }
    }
}
