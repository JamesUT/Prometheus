﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Prometheus_Entity;
using Prometheus_BLL;
using Prometheus_Exeception;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace Prometheus
{
    /// <summary>
    /// Interaction logic for StudentUpdateInformation.xaml
    /// </summary>
    public partial class StudentUpdateInformation : Window
    {

        SqlConnection connObj = null;
        SqlDataReader reader = null;
        SqlCommand cmd = null;
        string connStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        DataTable dt = null;

        public StudentUpdateInformation(int studentID)
        {
            InitializeComponent();
            txt_Id.Text = Convert.ToString(studentID);
            txt_Id.IsEnabled = false;
            connObj = new SqlConnection();
            connObj.ConnectionString = connStr;
            cmd = new SqlCommand("Group1.usp_SearchStudent", connObj);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Sid", studentID);
            connObj.Open();
            dt = new DataTable();
            reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                dt.Load(reader);
            }
            DataRow dr = dt.Rows[0];
            if (!dr.IsNull("StudentID"))
            {
                txt_teacherFName.Text = dr["FName"].ToString();
                txt_teacherLName.Text = dr["LName"].ToString();
                txt_teacherAddress.Text = dr["Address"].ToString();
                txt_teacherCity.Text = dr["City"].ToString();
                txt_teacherPh.Text = dr["MobileNo"].ToString();
                dp_teacherDOB.Text = dr["DOB"].ToString();
                pb_password.Password = dr["Password"].ToString();
            }
            else
                MessageBox.Show("No Records found with Student : " + studentID);
        }

        private void btn_update_Click(object sender, RoutedEventArgs e)
        {
            int rowAffected = 0;
            try
            {
                connObj = new SqlConnection();
                connObj.ConnectionString = connStr;
                cmd = new SqlCommand("Group1.usp_UpdateStudent", connObj);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Sid", txt_Id.Text);
                cmd.Parameters.AddWithValue("@Fname", txt_teacherFName.Text);
                cmd.Parameters.AddWithValue("@Lname", txt_teacherLName.Text);
                cmd.Parameters.AddWithValue("@address", txt_teacherAddress.Text);
                cmd.Parameters.AddWithValue("@dob", Convert.ToDateTime(dp_teacherDOB.Text));
                cmd.Parameters.AddWithValue("@city", txt_teacherCity.Text);
                cmd.Parameters.AddWithValue("@password", pb_password.Password);
                cmd.Parameters.AddWithValue("@mobileNo", txt_teacherPh.Text);
                connObj.Open();
                rowAffected = cmd.ExecuteNonQuery();
                if(rowAffected > 0)
                {
                    MessageBox.Show("Information Updated!");
                }
                else
                {
                    MessageBox.Show("Information not updated!");
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                if (connObj.State == ConnectionState.Open) connObj.Close();
            }
        }
    }
}
