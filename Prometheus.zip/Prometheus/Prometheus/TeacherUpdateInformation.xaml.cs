﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Prometheus_Entity;
using Prometheus_BLL;
using Prometheus_Exeception;
using System.Data;
using System.Data.SqlClient;

namespace Prometheus
{
    /// <summary>
    /// Interaction logic for TeacherUpdateInformation.xaml
    /// </summary>
    public partial class TeacherUpdateInformation : Window
    {
        public TeacherUpdateInformation()
        {
            InitializeComponent();
        }

        public TeacherUpdateInformation(string ID)
        {
            InitializeComponent();
            txt_teacherId.Text = ID;
            TeacherValidations searchTeacher = new TeacherValidations();
            DataTable dt = searchTeacher.searchTeacher_BLL(Convert.ToInt32(ID));

            DataRow dr = dt.Rows[0];
            if(!dr.IsNull("TeacherID"))
            {
                txt_teacherFName.Text = dr["FName"].ToString();
                txt_teacherLName.Text = dr["LName"].ToString();
                txt_teacherAddress.Text = dr["Address"].ToString();
                txt_teacherCity.Text = dr["City"].ToString();
                txt_teacherPh.Text = dr["MobileNo"].ToString();
                dp_teacherDOB.Text = dr["DOB"].ToString();
                pb_password.Password = dr["Password"].ToString();
                txt_isAdmin.Text = dr["IsAdmin"].ToString();
            }
            else
                MessageBox.Show("No Records found with Teacher : " + ID);

        }

        private void btn_update_Click(object sender, RoutedEventArgs e)
        {
            TeacherValidations updateTeacher = new TeacherValidations();
            Teacher teacher = new Teacher();
            teacher.TeacherID = Convert.ToInt32(txt_teacherId.Text);
            teacher.FName = txt_teacherFName.Text;
            teacher.LName = txt_teacherLName.Text;
            teacher.Address = txt_teacherAddress.Text;
            teacher.DOB = Convert.ToDateTime(dp_teacherDOB.Text);
            teacher.City = txt_teacherCity.Text;
            teacher.Password = pb_password.Password;
            teacher.MobileNo = Convert.ToInt64(txt_teacherPh.Text);
            teacher.IsAdmin = Convert.ToBoolean(txt_isAdmin.Text);

            int rowsaffected = updateTeacher.updateTeacher_BLL(teacher);
            if(rowsaffected > 0)
            {
                MessageBox.Show("Profile Updated!");
            }
            else
            {
                MessageBox.Show("Profile not Updated!");
            }
            //updateTeacher.updateTeacher_BLL();
        }
    }
}
